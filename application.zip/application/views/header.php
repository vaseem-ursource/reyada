
<?php include("nav.php");?>
<?php include("display_status.php");?>
<?php include("modals.php");?>
<?php include("mob_modals.php");?>
<?php include("bookingmodals.php");?>
<?php include("bookatourmodal.php");?>
<?php include("redirect.php");?>
<?php include("mob_redirect.php");?>

