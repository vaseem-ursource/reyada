
<?php include("nav_blog.php");?>
<?php include("modals.php");?>
<?php include("mob_modals.php");?>
<?php include("bookingmodals.php");?>
<?php include("bookatourmodal.php");?>
<?php include("redirect.php");?>
<?php include("mob_redirect.php");?>