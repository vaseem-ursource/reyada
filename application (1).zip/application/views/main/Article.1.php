
<!--==========================
    Intro Section
  ============================-->
  <section id="intro" class="clearfix align-middle " style="background:url('<?= base_url()?>image/articles/article1.jpg') center  no-repeat;background-size: cover;height:60vh;-webkit-filter: brightness(75%); filter: brightness(75%);">
  </section><!-- #intro -->

   <!--==========================
      Article
    ============================-->
    <section id="team" class="">
      <div class="container">
        <div class="section-header pb-1 col-md-9 pl-0">
          <h3 class="text-left text-dark">Lorem Ipsum Neque porro</h3>
          <small>22, Jan 19</small>
          <small class="pull-right">By John Smith</small>
        </div>
        <div class="section-header p-1 col-md-9"></div>
        <div class="pt-4 row">
            <div class="col-lg-9 col-md-9 wow fadeInUp p-3 text-justify">
                <p><b>Lorem Ipsum Neque porro</b>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin in rhoncus tortor. Praesent ut lectus eget dui iaculis iaculis. Sed non eros varius, maximus velit non, lacinia ligula. Mauris bibendum at arcu vitae feugiat. Vivamus pretium dignissim tincidunt. Sed consectetur quam ut massa bibendum, vel venenatis dui condimentum. Nulla rhoncus velit mauris, vel elementum mi rhoncus quis. Integer porta ut nunc quis pulvinar.</p>

                <p>Cras nec nulla purus. Fusce nec posuere magna. Vivamus maximus, est ac vulputate commodo, felis velit sollicitudin lorem, vitae pulvinar velit tortor nec erat. Donec posuere lectus vel dui porttitor, sed semper ex venenatis. Morbi vel elit commodo, dictum lectus porttitor, tincidunt enim. In eu nunc lobortis, sodales nisi nec, consequat sem. Maecenas eu purus a odio varius bibendum. Curabitur mattis pulvinar mattis. Morbi scelerisque odio arcu, ut imperdiet quam facilisis eu. Nulla sed bibendum diam. In eget orci in quam laoreet cursus. Maecenas hendrerit leo id tortor rhoncus, sit amet elementum elit rutrum. Cras mattis bibendum enim, a lacinia turpis accumsan a.</p>

                <img class="card-img-top py-1" src="<?= base_url()?>image/articles/a1.jpeg" alt="Card image cap">
                
                <p>Nam a turpis enim. Sed tempus at urna eu ultrices. Vivamus nibh orci, lobortis ut porttitor et, venenatis efficitur dolor. Vestibulum volutpat ac neque eu accumsan. Nam quis nunc vitae ex pellentesque pulvinar. Etiam lacinia dolor sed magna sagittis mollis. Proin ex tortor, pretium et iaculis sed, posuere et purus. Nulla facilisi. Morbi vitae metus id nibh dictum mollis sed ac metus.</p>

                <ul>
                    <li type="circle" class="py-3">
                        Aliquam pellentesque vitae ex vel viverra.
                    </li>
                    <li type="circle" class="py-3">
                        porttitor vehicula justo
                    </li>
                    <li type="circle" class="py-3">
                        Nunc egestas aliquam felis
                    </li>
                </ul>
                <p>Curabitur luctus vehicula est vel viverra. Aliquam pellentesque vitae ex vel viverra. Sed ac felis erat. Nulla vulputate rutrum blandit. Nam a ante vitae velit mollis feugiat. Pellentesque ut ipsum id dolor malesuada cursus. Proin non nulla maximus, sodales justo vel, iaculis nisl.</p>

                <p>Sed turpis sem, pulvinar eget risus a, porttitor vehicula justo. Pellentesque bibendum varius velit quis dictum. Ut eget tellus mauris. Proin eleifend eros vel lacinia pretium. Aenean pretium, est non vehicula dictum, mauris lorem consequat tortor, et condimentum velit ex nec sapien. Nunc egestas aliquam felis eu dignissim. Suspendisse lobortis aliquam finibus.</p>

                <h3 class="text-center pt-3">Share this Article</h3>
                <h4 class="text-center text-dark pb-5">
                    <a href="#"><i class="fa fa-facebook px-3 text-dark"></i></a>
                    <a href="#"><i class="fa fa-linkedin px-3 text-dark"></i></a>
                    <a href="#"><i class="fa fa-twitter px-3 text-dark"></i></a>
                </h4>
               <span class="mb-1">Tags : </span>
               <span class="btn btn-outline-secondary text-uppercase mb-1">START UPS</span>
               <span class="btn btn-outline-secondary text-uppercase mb-1">Tips</span>
               <span class="btn btn-outline-secondary text-uppercase mb-1">FreeLance</span>
               <span class="btn btn-outline-secondary text-uppercase mb-1">News</span>
               <span class="btn btn-outline-secondary text-uppercase mb-1">START UPS</span>
               <span class="btn btn-outline-secondary text-uppercase mb-1">FreeLance</span>
               <span class="btn btn-outline-secondary text-uppercase mb-1">START UPS</span>
               <span class="btn btn-outline-secondary text-uppercase mb-1">Tips</span>
               <span class="btn btn-outline-secondary text-uppercase mb-1">FreeLance</span>
               <span class="btn btn-outline-secondary text-uppercase mb-1">News</span>
               <span class="btn btn-outline-secondary text-uppercase mb-1">START UPS</span>
               <span class="btn btn-outline-secondary text-uppercase mb-1">FreeLance</span>
            </div>

            <div class="col-lg-3 col-md-3 wow fadeInUp p-1 lap">
                  <img class="" width="100%" height="200px" src="<?= base_url()?>image/articles/a2.jpg" alt="Card image cap">
                    <div class="container mt-3">
                      <div class="accordian">
                        <ul>
                          <li><input type="checkbox" checked=""><i></i>
                            <h6><span style="border-left:2px solid #343a40;padding:4px"></span> Category</h6>
                            <div class="artlist">
                              <a href="#"><div class="artlist_content">All Categories</div></a>
                              <a href="#"><div class="artlist_content">Startup News</div></a>
                              <a href="#"><div class="artlist_content">Founder Talk</div></a>
                              <a href="#"><div class="artlist_content">Mentor Tips</div></a>
                              <a href="#"><div class="artlist_content">Business</div></a>
                              <a href="#"><div class="artlist_content">Events</div></a>
                              <a href="#"><div class="artlist_content">Reviews</div></a>
                            </div>
                          </li>
                          <li><input type="checkbox" checked=""><i></i>
                            <h6><span style="border-left:2px solid #343a40;padding:4px"></span> Popular Article</h6>
                            <div class="artlist">
                              <a href="#"><div class="artlist_content">Lorem Ipsum Neque porro<small>Co-Founder</small></div></a>
                              <a href="#"><div class="artlist_content"> Neque porro Ipsum</div></a>
                            </div>
                          </li>
                          <li><input type="checkbox" checked=""><i></i>
                            <h6><span style="border-left:2px solid #343a40;padding:4px"></span> Popular Tags</h6>
                            <div class="artlist">
                              <div class="artlist_content">
                                <a href="#"><span class="btn btn-outline-secondary text-uppercase mb-1">START UPS</span></a>
                                <a href="#"><span class="btn btn-outline-secondary text-uppercase mb-1">Tips</span></a>
                                <a href="#"><span class="btn btn-outline-secondary text-uppercase mb-1">FreeLance</span></a>
                                <a href="#"><span class="btn btn-outline-secondary text-uppercase mb-1">News</span></a>
                                <a href="#"><span class="btn btn-outline-secondary text-uppercase mb-1">START UPS</span></a>
                              </div>
                            </div>
                          </li>
                          <li><input type="checkbox" checked=""><i></i>
                            <h6><span style="border-left:2px solid #343a40;padding:4px"></span> Instagram</h6>
                            <div class="artlist">
                              <div class="artlist_content">Some content!</div>
                            </div>
                            <div class="artlist">
                              <div class="artlist_content">Some content!</div>
                            </div>
                          </li>
                        </ul>
                      </div>
                    </div>
            </div>
        </div>

      </div>
    </section><!-- #team -->