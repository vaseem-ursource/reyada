<!-- <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script> -->
<?php include("nav.php");?>
<?php include("display_status.php");?>
<?php include("modals.php");?>
<?php include("mob_modals.php");?>
<?php include("bookingmodals.php");?>
<?php include("bookatourmodal.php");?>
<?php include("redirect.php");?>
<?php include("mob_redirect.php");?>

