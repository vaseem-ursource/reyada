<?php include('account_master_start.php');?>

    <h5 class="text-left text-dark">Becoming a Reyada member comes along with many perks and services. Some of these services include:</h5> 
<?php include('account_master_end.php');?>
       

